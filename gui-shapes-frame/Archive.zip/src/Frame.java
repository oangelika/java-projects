import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class Frame extends JFrame implements ActionListener{

    private JMenuBar menuBar = new JMenuBar();

    private JMenu fileMenu = new JMenu("File");
    private JMenu drawMenu = new JMenu("Draw");
    private JMenu figureMenu = new JMenu("Figure");

    private JMenuItem openItem = new JMenuItem("Open");
    private JMenuItem saveItem = new JMenuItem("Save");
    private JMenuItem saveAsItem = new JMenuItem("Save As...");
    private JMenuItem quitItem = new JMenuItem("Quit");

    private JMenuItem colorItem = new JMenuItem("Color");
    private JMenuItem clearItem = new JMenuItem("Clear");

    private ButtonGroup buttonGroup = new ButtonGroup();
    private JRadioButton circleItem = new JRadioButton("Circle");
    private JRadioButton squareItem = new JRadioButton("Square");
    private JRadioButton penItem = new JRadioButton("Pen");

    private JToolBar toolBar = new JToolBar();
    private JLabel modeLabel = new JLabel();
    private JLabel statusLabel = new JLabel();

    private List <Shape> shapes = new ArrayList<>();
    private Color currentColor = Color.RED;
//    private boolean drawCircle = false;


    public Frame() {

        UIManager.put("MenuItem.acceleratorForeground", Color.BLUE);

//        JPanel panel = new JPanel();
//        this.getContentPane().setLayout(new FlowLayout());
//        this.add(panel);
        this.setSize(300, 300);

        this.setJMenuBar(menuBar);
        this.setTitle("Simple Draw");

        menuBar.add(fileMenu);
        menuBar.add(drawMenu);
        drawMenu.add(figureMenu);

        fileMenu.setMnemonic(KeyEvent.VK_F);
        drawMenu.setMnemonic(KeyEvent.VK_D);
        figureMenu.setMnemonic(KeyEvent.VK_F);



        openItem.setMnemonic(KeyEvent.VK_O);
        openItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(openItem);
        openItem.addActionListener(this);


        saveItem.setMnemonic(KeyEvent.VK_S);
        saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(saveItem);
        saveItem.addActionListener(this);


        saveAsItem.setMnemonic(KeyEvent.VK_A);
        KeyStroke saveKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK | KeyEvent.SHIFT_DOWN_MASK);
        saveAsItem.setAccelerator(saveKeyStroke);
        fileMenu.add(saveAsItem);
        saveAsItem.addActionListener(this);

        fileMenu.addSeparator();

        quitItem.setMnemonic(KeyEvent.VK_Q);
        quitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(quitItem);



        colorItem.setMnemonic(KeyEvent.VK_C);
        KeyStroke colorKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.ALT_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
        colorItem.setAccelerator(colorKeyStroke);
        drawMenu.add(colorItem);

        drawMenu.addSeparator();

        clearItem.setMnemonic(KeyEvent.VK_C);
        KeyStroke clearKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK | KeyEvent.SHIFT_DOWN_MASK);
        clearItem.setAccelerator(clearKeyStroke);
        drawMenu.add(clearItem);



        buttonGroup.add(circleItem);
        circleItem.setMnemonic(KeyEvent.VK_C);
        KeyStroke circleKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_C, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
//        circleItem.setAccelerator(circleKeyStroke);
        figureMenu.add(circleItem);


        buttonGroup.add(squareItem);
        squareItem.setMnemonic(KeyEvent.VK_R);
        KeyStroke squareKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_R, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
//        squareItem.setAccelerator(squareKeyStroke);
        figureMenu.add(squareItem);


        buttonGroup.add(penItem);
        penItem.setMnemonic(KeyEvent.VK_P);
        KeyStroke penKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_E, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
//        penItem.setAccelerator(penKeyStroke);
        figureMenu.add(penItem);



        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                for (Shape shape : shapes) {
                    g.setColor(shape.getColor());
                    if (shape.getType().equals("circle")) {
                        g.fillOval(shape.getX() - shape.getSize() / 2, shape.getY() - shape.getSize() / 2, shape.getSize(), shape.getSize());
                    } else if (shape.getType().equals("square")) {
                        g.fillRect(shape.getX() - shape.getSize() / 2, shape.getY() - shape.getSize() / 2, shape.getSize(), shape.getSize());
                    } else {
                        g.drawLine(shape.getStartX(), shape.getStartY(), shape.getEndX(), shape.getEndY());
                    }
                }
            }
        };

        contentPane.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                if(penItem.isSelected()) {
                    int x = e.getX();
                    int y = e.getY();
                    shapes.add(new Shape(x, y, x, y, currentColor, "line"));
                    contentPane.repaint();
                }
            }
        });


        contentPane.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                if(circleItem.isSelected()) {
                    shapes.add(new Shape(x, y, getRandomColor(), "circle"));
                }
                if(squareItem.isSelected()) {
                    shapes.add(new Shape(x, y, getRandomColor(), "square"));
                }

//              shapes.add(new Shape(x, y, getRandomColor(), drawCircle));
                contentPane.repaint();
            }
        });

        colorItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JColorChooser colorChooser = new JColorChooser();
               currentColor = colorChooser.showDialog(null, "Choose Color", currentColor);

            }
        });

        clearItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                shapes.clear();
                contentPane.repaint();
            }
        });



        getContentPane().add(contentPane, BorderLayout.CENTER);

        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }



    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == openItem) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                System.out.println(file);
            }
        }

        if (e.getSource() == saveItem) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                System.out.println(file);
            }
        }

        if (e.getSource() == saveAsItem) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                System.out.println(file);

            }
        }

    }

    private Color getRandomColor() {
        int r = (int) (Math.random() * 256);
        int g = (int) (Math.random() * 256);
        int b = (int) (Math.random() * 256);
        return new Color(r, g, b);
    }
}